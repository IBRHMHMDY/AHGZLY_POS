import 'package:flutter/foundation.dart';

@immutable
abstract class ShiftEvent {}

class CheckActiveShiftEvent extends ShiftEvent {}

class OpenShiftSubmittedEvent extends ShiftEvent {
  final int startingCash;
  final int cashierId;
  OpenShiftSubmittedEvent({required this.startingCash, required this.cashierId});
}

class CloseShiftSubmittedEvent extends ShiftEvent {
  final int shiftId;
  final int actualCash;
  CloseShiftSubmittedEvent({required this.shiftId, required this.actualCash});
}

class LoadShiftsHistoryEvent extends ShiftEvent {
  final bool isLoadMore;
  LoadShiftsHistoryEvent({this.isLoadMore = false});
} // 🚀 [Sprint 2]