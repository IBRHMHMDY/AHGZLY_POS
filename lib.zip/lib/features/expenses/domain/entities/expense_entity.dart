import 'package:equatable/equatable.dart';

class ExpenseEntity extends Equatable {
  final int? id;
  final int shiftId;
  final int amount; 
  final String reason;
  final DateTime createdAt; // [Refactored]: تغيير من String إلى DateTime

  const ExpenseEntity({
    this.id,
    required this.shiftId,
    required this.amount,
    required this.reason,
    required this.createdAt,
  });

  @override
  List<Object?> get props => [id, shiftId, amount, reason, createdAt];
}